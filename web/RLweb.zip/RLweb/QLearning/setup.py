from setuptools import setup

setup(name='QLearning',
      version='0.1',
      description='Q-Learning Algorithm system',
      url='',
      author='Takao Mizuno',
      author_email='t.mizuno@9dw.jp',
      license='NDW',
      packages=['QLearning'],
      zip_safe=False)
